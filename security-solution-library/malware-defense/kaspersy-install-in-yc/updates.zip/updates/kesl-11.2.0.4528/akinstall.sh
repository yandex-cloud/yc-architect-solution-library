#!/usr/bin/env sh
set -u
set -e

readonly APP_NAME=kesl
readonly PKG_NAME=kesl
readonly GUI_PKG_NAME=kesl-gui
readonly KUD_FILENAME=kesl.kud
autocleanup='no'
unset LD_LIBRARY_PATH

parse_version_string()
{
    local _ver="$1"
    shift
    local _cmd=''
    _cmd=$(cat << 'AWK_PROGRAM'
BEGIN {
    n = split(version, a, /[.-]/);
    if (n < num)
    {
        printf("Invalid version format: \"%s\". Must have at least %s numbers but has %s\n", version, num, n) | "cat 1>&2";
        exit 1;
    }

    for (i = 1; i <= num; ++i)
    {
        if (a[i] !~ /^[0-9]+$/)
        {
            printf("Version part must be a number but: \"%s\"\n", a[i]) | "cat 1>&2";
            exit 1;
        }
        printf("${%s:+eval \"${%s}='%s'\"};", i, i, a[i]);
    }
    exit;
}
AWK_PROGRAM
        )

    local _code=''
    _code="$(awk -v version="${_ver}" -v num="$#" -- "${_cmd}")" || return $?
    eval "${_code}"
    return $?
}

read_kud_value()
{
    local kud="$1"
    local section="$2"
    local name="$3"

    awk -v "section=$section" -v "name=$name" 'BEGIN { sec = "" }
    {
        if ( $0 ~ /^\s*\[.*\]/ ) { gsub(/(^[ \t\r\n]*\[|\][ \t\r\n]*)/,""); sec=$1; next; }
        if ( ($0 ~ "^[ \t\r\n]*" name "=") && sec == section ) { gsub("(^[ \t]*" name "=|[ \t\r\n]*$)",""); print $1; }
    }' "${kud}" </dev/null
}
read_ini_value()
{
    local ini="$1"
    local name="$2"

    awk -v "name=${name}" 'BEGIN { }
    {
        if ($0 ~ "^[ \t\r\n]*" name "=")
        {
            gsub("(^[ \t]*" name "=|[ \t\r\n]*$)","");
            print toupper($1);
        }
    }' "${ini}" </dev/null
}

is_app_configured()
{
    local INI_FILEPATH='/var/opt/kaspersky/kesl/common/kesl.ini'
    if [ ! -f "${INI_FILEPATH}" ]; then
        return 1
    fi
    local configured=''
    if configured="$(read_ini_value "${INI_FILEPATH}" UseFanotify)" && [ -n "${configured}" ] ; then
        return 0
    fi
    return 1
}

has_install_gui()
{
    local config="$1"
    local use_gui=''
    use_gui="$(read_ini_value "$config" USE_GUI)"
    if [ "$use_gui" = "YES" -o "$use_gui" = "Y" -o "$use_gui" = "1" -o "$use_gui" = "TRUE" ] ; then
        return 0
    fi
    return 1
}

is_app_running()
{
    local has_systemd=0
    systemctl --version >/dev/null 2>&1 || has_systemd=$?
    local is_running=0
    if [ "$has_systemd" -ne 0 ] ; then
        /opt/kaspersky/kesl/shared/kesl-supervisor status >/dev/null 2>&1 || is_running=$?
    else
        systemctl status kesl-supervisor.service >/dev/null 2>&1 || is_running=$?
    fi
    return ${is_running}
}

start_application_after_upgrade()
{
    local has_systemd=0
    systemctl --version >/dev/null 2>&1 || has_systemd=$?
    if [ "$has_systemd" -ne 0 ] ; then
        exec2log 5 /opt/kaspersky/kesl/shared/kesl-supervisor start
    else
        exec2log 5 systemctl start kesl-supervisor.service
    fi
}

fatal_error()
{
    local err="$1" ; shift

    report "$@"

    if [ -f "$install_log" ] ; then
        echo "INSTALL LOG: $install_log" >&2
        cat "$install_log"
    fi

    echo "FATAL ERROR:" "$@" >&2

    exit $err
}

report()
{
    local date="$(date "+%Y/%m/%d %T")"
    echo "[$date]" "$@" >>"$install_log"
}

run2log()
{

    report "Executing" "$@"

    "$@" >>"$install_log" 2>&1
    return $?
}

exec2log()
{
    local err="$1" ; shift

    report "Executing" "$@"

    if ! "$@" >>"$install_log" 2>&1
    then
        fatal_error $err "'$@' failed!"
    fi
    return 0
}


cd "$(dirname "$0")"
srcdir="$(pwd)"

logdir="/var/log/kaspersky/klnagent"
install_log="$logdir/akinstall-$APP_NAME.$(date "+%Y%m%d%H%M%S").log"
if [ ! -d "$logdir" ] ; then
    mkdir -p "$logdir"
    chmod 0770 "$logdir"
fi

kud_file="$srcdir/$KUD_FILENAME"

if [ ! -f "$kud_file" ] ; then
    fatal_error 1 "Cannot find file $KUD_FILENAME"
fi

version=$(read_kud_value "${kud_file}" Version DisplayVersion)
appversion=${version%.*}
apprelease=${version##*.}

report "+++ Installation $APP_NAME version $version started"

pkgtype=$(read_kud_value "${kud_file}" Setup PkgMan)

has_rpm=0
has_dpkg=0
if [ "$pkgtype" = "RPM" ] ; then
    has_rpm=0
    has_dpkg=1
elif [ "$pkgtype" = "DEB" ] ; then
    has_rpm=1
    has_dpkg=0
elif [ "$pkgtype" = "ALL" ] ; then
    rpm -q rpm >/dev/null 2>&1 || has_rpm=$?
    dpkg -l dpkg >/dev/null 2>&1 || has_dpkg=$?
else
    fatal_error 2 "Unsupported package manager type: '$pkgtype'"
fi

if [ "$has_rpm" -ne 0 -a "$has_dpkg" -ne 0 ] ; then
    fatal_error 2 "Threre is no dpkg or rpm package manager on the system"
fi

arch=''
suitable_packages=''
suitable_gui_packages=''
appversion_for_regex=$(echo "${appversion}" | sed 's/\./\\\./g')
apprelease_for_regex=$(echo "${apprelease}" | sed 's/\./\\\./g')
old_apt=0
if [ ${has_dpkg} -eq 0 ] ; then
    arch="$(dpkg --print-architecture | sed 's/i[3456]86/i386/')"
    suitable_packages="$(ls -1d ./* | grep -G "^\./${PKG_NAME}_${appversion_for_regex}-${apprelease_for_regex}\(\..\+\)\?_${arch}\.deb$")" || true
    suitable_gui_packages="$(ls -1d ./* | grep -G "^\./${GUI_PKG_NAME}_${appversion_for_regex}-${apprelease_for_regex}\(\..\+\)\?_${arch}\.deb$")" || true
    pkgtype="DEB"
    check_already_installed_command="dpkg -l ${PKG_NAME} | tail -1 | grep -G \"^[uriph]i[[:space:]]\""
    check_gui_already_installed_command="dpkg -l ${GUI_PKG_NAME} | tail -1 | grep -G \"^[uriph]i[[:space:]]\""

    apt_version=''
    apt_version="$(apt-get --version | head -1 |  sed "s/apt[[:space:]]\+\([0-9\.]\+\)[[:space:]]\+.\+$/\\1/g")" || true
    echo "${apt_version}"
    apt_major=''
    apt_minor=''
    if ! parse_version_string "${apt_version}" apt_major apt_minor; then
        apt_major=9999
        apt_minor=9999
    fi

    if [ ${apt_major} -gt 1 ] ; then
        old_apt=0
    elif [ ${apt_major} -lt 1 ] ; then
        old_apt=1
    else
        if [ ${apt_minor} -gt 0 ] ; then
            old_apt=0
        else
            old_apt=1
        fi
    fi
    get_version_command="dpkg-query --showformat=\${Version} --show ${PKG_NAME}"
    if [ ${old_apt} -eq 1 ] ; then
        install_command="dpkg -i"
        update_command="dpkg -i"
        downgrade_command="dpkg -i --force-downgrade"
    else
        install_command="apt-get -y install"
        update_command="apt-get -y install"
        downgrade_command="apt-get -y install --allow-downgrades"
    fi
    uninstall_command="apt-get -y purge"
else
    arch="$(rpm --showrc | grep 'install arch' | awk '{print $4}' | sed 's/athlon\|geode\|i[3456]86\|pentium[34]/i386/')"
    suitable_packages="$(ls -1d ./* | grep -G "^\./${PKG_NAME}-${appversion_for_regex}-${apprelease_for_regex}\(\..\+\)\?\.${arch}\.rpm$")" || true
    suitable_gui_packages="$(ls -1d ./* | grep -G "^\./${GUI_PKG_NAME}-${appversion_for_regex}-${apprelease_for_regex}\(\..\+\)\?\.${arch}\.rpm$")" || true
    pkgtype="RPM"
    check_already_installed_command="rpm -q ${PKG_NAME}"
    check_gui_already_installed_command="rpm -q ${GUI_PKG_NAME}"
    get_version_command="rpm -q --queryformat=%{VERSION}-%{RELEASE} ${PKG_NAME}"
    if yum --version >/dev/null 2>&1; then
        install_command="yum -y install"
        update_command="yum -y install"
        downgrade_command="yum -y downgrade"
        uninstall_command="yum -y remove"
    elif zypper --version >/dev/null 2>&1; then
        install_command="zypper --non-interactive --no-refresh --no-cd install --allow-unsigned-rpm"
        update_command="zypper --non-interactive --no-refresh --no-cd install --allow-unsigned-rpm"
        downgrade_command="zypper --non-interactive --no-refresh --no-cd install --oldpackage --allow-unsigned-rpm"
        uninstall_command="zypper --non-interactive --no-refresh --no-cd remove"
    elif apt-get --version >/dev/null 2>&1; then
        install_command="apt-get -y install"
        update_command="apt-get -y install"
        downgrade_command="apt-get -y install --allow-downgrades"
        uninstall_command="apt-get -y purge"
    elif urpmi --version >/dev/null 2>&1; then
        install_command="urpmi --auto"
        update_command="urpmi --auto"
        downgrade_command="urpmi --auto --downgrade"
        uninstall_command="urpme --auto"
    fi
fi

tar_subfolder=''
case "$arch" in
  e2k*)
    tar_subfolder='e2k';;
  amd64|x86_64)
    tar_subfolder='x86_64';;
  i386)
    tar_subfolder='i386';;
  *)
    fatal_error 2 "Unsupported architecture '$arch'";;
esac

configfname=$(read_kud_value "${kud_file}" Setup ConfigFile)
config="$srcdir/$configfname"
if [ ! -f "$config" ] ; then
    fatal_error 2 "Cannot find config file '$configfname'"
fi

already_installed=0
eval ${check_already_installed_command} > /dev/null 2>&1 || already_installed=$?

gui_already_installed=0
eval ${check_gui_already_installed_command} > /dev/null 2>&1 || gui_already_installed=$?

install_gui=0
has_install_gui "$config" || install_gui=$?

if [ -z "${suitable_packages}" ] ; then
    fatal_error 2 "There is no any package for '$arch'"
fi
number_of_packages=$(echo "${suitable_packages}" | wc -l)
if [ "${number_of_packages}" -ne "1" ] ; then
    fatal_error 2 "There are more than one package for '$arch'"
fi
pkgfnames="${suitable_packages}"
if [ "${install_gui}" -eq 0 ] ; then
    if [ -z "${suitable_gui_packages}" ] ; then
        fatal_error 2 "There is no any gui package for '$arch'"
    fi
    number_of_packages=$(echo "${suitable_gui_packages}" | wc -l)
    if [ "${number_of_packages}" -ne "1" ] ; then
        fatal_error 2 "There are more than one gui package for '$arch'"
    fi
    pkgfnames="${pkgfnames} ${suitable_gui_packages}"
fi
uninstall_pkgnames="${PKG_NAME}"
if [ "${gui_already_installed}" -eq 0 ] ; then
    uninstall_pkgnames="${GUI_PKG_NAME} ${uninstall_pkgnames}"
fi

installed_and_not_configured=0
if [ "${already_installed}" -eq 0 ] ; then
    installed_version=0
    installed_version=$(${get_version_command})

    installed_major=0
    installed_minor=0
    installed_fix=0
    installed_build=0

    if ! parse_version_string "${installed_version}" installed_major installed_minor installed_fix installed_build; then
        report "Invalid installed package version format"
        exit 2
    fi

    if ! parse_version_string "${appversion}" new_major new_minor new_fix; then
        report "Invalid new package version format"
        exit 2
    fi
    app_running_state=0
    if is_app_running; then
        app_running_state=1
    fi
    version_increment=$((${new_major} - ${installed_major}))
    if [ ${version_increment} -lt 0 ] ; then
        report "The package already installed"
        exit 72
    fi
    if [ ${version_increment} -eq 0 ] ; then
        version_increment=$((${new_minor} - ${installed_minor}))
        if [ ${version_increment} -lt 0 ] ; then
            report "The package already installed"
            exit 72
        fi
    fi
    if [ ${version_increment} -eq 0 ] ; then
        version_increment=$((${new_fix} - ${installed_fix}))
        if [ ${version_increment} -lt 0 ] ; then
            report "The package already installed"
            exit 72
        fi
    fi
    if [ ${version_increment} -eq 0 ] ; then
        version_increment=$((${apprelease} - ${installed_build}))
        if [ ${version_increment} -lt 0 ] ; then
            update_command=${downgrade_command}
        fi
    fi
    if [ ${version_increment} -eq 0 ] ; then
        if [ "${gui_already_installed}" -ne 0 -a "${install_gui}" -eq 0 ] ; then
            report "Install gui"
            (cd "$srcdir" && exec2log 3 ${install_command} ${suitable_gui_packages})
        elif [ "${gui_already_installed}" -eq 0 -a "${install_gui}" -ne 0 ] ; then
            report "Uninstall gui"
            exec2log 4 ${uninstall_command} ${GUI_PKG_NAME}
        fi
        if is_app_configured; then
            report "The package already installed"
            exit 72
        else
            installed_and_not_configured=1
        fi
    elif ! is_app_configured ; then
        report "Not configured. Uninstall old version"
        exec2log 4 ${uninstall_command} ${uninstall_pkgnames}
        if [ ${old_apt} -eq 1 ] ; then
            for package in ${pkgfnames} ; do
                (cd "$srcdir" && exec2log 3 ${install_command} ${package})
            done
        else
            (cd "$srcdir" && exec2log 3 ${install_command} ${pkgfnames})
        fi
        installed_and_not_configured=1
    fi
    if [ ${installed_and_not_configured} -ne 1 ] ; then
        if [ "${gui_already_installed}" -eq 0 -a "${install_gui}" -ne 0 ] ; then
            report "Uninstall gui"
            exec2log 4 ${uninstall_command} ${GUI_PKG_NAME}
        fi
        report "Try to update kesl '${installed_version}' to '${appversion}-${apprelease}'."
        readonly is_eula_agreed=$(read_ini_value "${config}" EULA_AGREED)
        readonly is_privacy_policy=$(read_ini_value "${config}" PRIVACY_POLICY_AGREED)
        readonly is_ksn=$(read_ini_value "${config}" USE_KSN)
        if [ "${is_eula_agreed}" = "YES" -o "${is_eula_agreed}" = "Y" -o "${is_eula_agreed}" = "1" -o "${is_eula_agreed}" = "TRUE" ] ; then
            export KESL_EULA_AGREED="y"
        else
            export KESL_EULA_AGREED="n"
        fi
        if [ "${is_privacy_policy}" = "YES" -o "${is_privacy_policy}" = "Y" -o "${is_privacy_policy}" = "1" -o "${is_privacy_policy}" = "TRUE" ] ; then
            export KESL_PRIVACY_POLICY_AGREED="y"
        else
            export KESL_PRIVACY_POLICY_AGREED="n"
        fi
        if [ "${is_ksn}" = "YES" -o "${is_ksn}" = "Y" -o "${is_ksn}" = "1" -o "${is_ksn}" = "TRUE" ] ; then
            export KESL_USE_KSN="y"
        else
            export KESL_USE_KSN="n"
        fi

        if [ ${old_apt} -eq 1 ] ; then
            for package in ${pkgfnames} ; do
                (cd "$srcdir" && exec2log 3 ${update_command} ${package})
            done
        else
            (cd "$srcdir" && exec2log 3 ${update_command} ${pkgfnames})
        fi
        unset KESL_USE_KSN
        unset KESL_PRIVACY_POLICY_AGREED
        unset KESL_EULA_AGREED

        if [ ${app_running_state} -ne 0 ] ; then
            report "Restart the application"
            exit 73
        else
            start_application_after_upgrade
            exit 0
        fi
    fi
fi

if [ ${installed_and_not_configured} -ne 1 ] ; then
    if [ ${old_apt} -eq 1 ] ; then
        for package in ${pkgfnames} ; do
            (cd "$srcdir" && exec2log 3 ${install_command} ${package})
        done
    else
        (cd "$srcdir" && exec2log 3 ${install_command} ${pkgfnames})
    fi
fi

readonly bases_tarball="${srcdir}/kesl-bases.tgz"
if [ -f "${bases_tarball}" ] ; then
    report "Bases tarball '${bases_tarball}' detected. Try to install bases."
    rc=0
    run2log tar tzvf "${bases_tarball}" -C / "${tar_subfolder}" --strip-components=1 > /dev/null || rc=$?
    if [ "$rc" -eq 0 ] ; then
        run2log tar xzvf "${bases_tarball}" -C / "${tar_subfolder}" --strip-components=1 > /dev/null || rc=$?
    fi
    if [ "$rc" -ne 0 ] ; then
        report "Error occured. There is invalid '${bases_tarball}' package. Continue installation without bases."
    fi
fi

setup="/opt/kaspersky/$APP_NAME/bin/$APP_NAME-setup.pl"
rc=0
run2log $setup "--autoinstall=$config" || rc=$?

report "$APP_NAME-setup.pl rc=$rc"

isfatal='yes'

case "$rc" in
    0)
        report "Installation completed successfully"
        exit 0
        ;;
    7?)
        isfatal=''
        ;;
esac

if [ -n "$isfatal" ] ; then
    report "Fatal error occured, remove installed package"

    case "$pkgtype" in
        RPM)
            exec2log 4 rpm -e "$PKG_NAME"
            if [ "$autocleanup" = 'yes' ] ; then
                cleanup="/var/opt/kaspersky/$APP_NAME/bin/cleanup.sh"
                if [ -x  "$cleanup" ] ; then
                    exec2log 4 $cleanup --confirm-delete
                fi
            fi
            ;;
        DEB)
            dpkgopts='-r'
            [ "$autocleanup" = 'yes' ] && dpkgopts='-P'
            exec2log 4 dpkg $dpkgopts "$PKG_NAME"
            ;;
    esac
fi
exit $rc
