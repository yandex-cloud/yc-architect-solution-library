# Импорт данных Трекера в ClickHouse
