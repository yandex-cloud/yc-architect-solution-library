"""
Exception
 +- ValueError
 |   +- DurationFormattingException
"""


class DurationFormattingException(ValueError):
    ...
